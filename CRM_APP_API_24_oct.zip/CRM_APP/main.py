from fastapi import FastAPI
from database import engine
from models import Base
from routers import user, post, like

# Create the database tables
Base.metadata.create_all(bind=engine)

app = FastAPI()

# Include routers
app.include_router(user.router)
app.include_router(post.router)
app.include_router(like.router)

@app.get("/")
def read_root():
    return {"message": "Welcome to the CMS API"}
