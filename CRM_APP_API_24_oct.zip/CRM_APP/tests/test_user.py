from fastapi.testclient import TestClient
from main import app

client = TestClient(app)

def test_create_user():
    response = client.post("/accounts", json={"name": "Test User", "email": "test@example.com", "password": "password"})
    assert response.status_code == 200
    assert response.json()["name"] == "Test User"

def test_login():
    response = client.post("/accounts/login", data={"username": "test@example.com", "password": "password"})
    assert response.status_code == 200
    assert "access_token" in response.json()
