from pydantic import BaseModel
from typing import List, Optional
from datetime import datetime

class UserBase(BaseModel):
    name: str
    email: str

class UserCreate(UserBase):
    password: str

class User(UserBase):
    id: int

    class Config:
        orm_mode = True

class PostBase(BaseModel):
    title: str
    description: str
    content: str
    is_public: Optional[bool] = True

class PostCreate(PostBase):
    pass

class Post(PostBase):
    id: int
    created_at: datetime
    owner_id: int

    class Config:
        orm_mode = True

class LikeBase(BaseModel):
    post_id: int
    user_id: int

class Like(LikeBase):
    id: int

    class Config:
        orm_mode = True


class TokenData(BaseModel):
    id: Optional[int] = None  #