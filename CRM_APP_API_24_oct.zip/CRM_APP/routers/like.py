from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
import schemas, models
from database import get_db
from utils.security import get_current_user  # Make sure this import is correct

router = APIRouter()

@router.post("/like/{blog_id}", response_model=schemas.Like)
def like_blog(blog_id: int, db: Session = Depends(get_db), current_user: schemas.User = Depends(get_current_user)):
    like = models.Like(post_id=blog_id, user_id=current_user.id)
    db.add(like)
    db.commit()
    db.refresh(like)
    return like

@router.delete("/like/{blog_id}")
def unlike_blog(blog_id: int, db: Session = Depends(get_db), current_user: schemas.User = Depends(get_current_user)):
    like = db.query(models.Like).filter(models.Like.post_id == blog_id, models.Like.user_id == current_user.id).first()
    if not like:
        raise HTTPException(status_code=404, detail="Like not found")
    db.delete(like)
    db.commit()
    return {"detail": "Like removed"}
