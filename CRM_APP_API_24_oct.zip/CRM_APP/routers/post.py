from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
import schemas, models
from database import get_db
from utils.security import get_current_user  # Make sure this import is correct

router = APIRouter()

@router.post("/blog", response_model=schemas.Post)
def create_blog(post: schemas.PostCreate, db: Session = Depends(get_db), current_user: schemas.User = Depends(get_current_user)):
    new_post = models.Post(**post.dict(), owner_id=current_user.id)
    db.add(new_post)
    db.commit()
    db.refresh(new_post)
    return new_post

@router.get("/blog/{id}", response_model=schemas.Post)
def get_blog(id: int, db: Session = Depends(get_db)):
    post = db.query(models.Post).filter(models.Post.id == id).first()
    if post is None:
        raise HTTPException(status_code=404, detail="Post not found")
    return post

@router.put("/blog/{id}", response_model=schemas.Post)
def update_blog(id: int, post: schemas.PostCreate, db: Session = Depends(get_db), current_user: schemas.User = Depends(get_current_user)):
    post_db = db.query(models.Post).filter(models.Post.id == id, models.Post.owner_id == current_user.id).first()
    if not post_db:
        raise HTTPException(status_code=404, detail="Not authorized to update this post")
    post_db.title = post.title
    post_db.description = post.description
    post_db.content = post.content
    db.commit()
    return post_db

@router.delete("/blog/{id}")
def delete_blog(id: int, db: Session = Depends(get_db), current_user: schemas.User = Depends(get_current_user)):
    post_db = db.query(models.Post).filter(models.Post.id == id, models.Post.owner_id == current_user.id).first()
    if not post_db:
        raise HTTPException(status_code=404, detail="Not authorized to delete this post")
    db.delete(post_db)
    db.commit()
    return {"detail": "Post deleted"}
